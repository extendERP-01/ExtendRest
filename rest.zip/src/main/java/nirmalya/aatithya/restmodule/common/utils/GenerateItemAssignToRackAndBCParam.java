package nirmalya.aatithya.restmodule.common.utils;

import java.util.List;

import nirmalya.aatithya.restmodule.inventory.model.AllocateItemsToRackModel;

public class GenerateItemAssignToRackAndBCParam {

	public static String getSaveParam(List<AllocateItemsToRackModel> batch) {
		String s = "";
		String litem = "";
		
		System.out.println("batch " + batch);

		for (AllocateItemsToRackModel m : batch) {
			litem = litem + "(\"" + m.getPoNo() + "\",\"" + m.getGrn() + "\",\"" + m.getItemId() + "\","
					+ m.getQuantity() + ",\"" + m.getStoreId() + "\",\"" + m.getSubInventoryId() + "\",\""
					+ m.getWareHouseId() + "\",\"" + m.getRackId() + "\",\"" + m.getShelfName() + "\","
					+ m.getInspQuantity() + ",\"" + m.getCratedBy() + "\"),";
		}
		litem = litem.substring(0, litem.length() - 1);
		s = s + "@p_allocateSubQuery='" + litem + "',";

		if (s != "") {
			s = s.substring(0, s.length() - 1);

			s = "SET " + s + ";";
		}

		System.out.println(s);

		return s;
	}

	public static String getSaveBarcodeParam(List<AllocateItemsToRackModel> batch) {
		String s = "";
		String litem = "";

		for (AllocateItemsToRackModel m : batch) {
			litem = litem + "(@p_barcodeId,\"" + m.getPoNo() + "\",\"" + m.getGrn() + "\",\"" + m.getItemId() + "\",\""
					+ m.getStoreId() + "\",\"" + m.getSubInventoryId() + "\",\"" + m.getWareHouseId() + "\",\""
					+ m.getRackId() + "\",\"" + m.getShelfName() + "\",\""+ m.getBarcodeNo() +  "\",\""
					+ m.getBarCodeImageName() + "\",\"" + m.getCratedBy() + "\"),";
		}
		litem = litem.substring(0, litem.length() - 1);
		s = s + "@p_barcodeSubQuery='" + litem + "',";

		if (s != "") {
			s = s.substring(0, s.length() - 1);

			s = "SET " + s + ";";
		}

		System.out.println(s);

		return s;
	}

}
