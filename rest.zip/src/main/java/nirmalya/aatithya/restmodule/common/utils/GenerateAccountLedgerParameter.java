package nirmalya.aatithya.restmodule.common.utils;

import nirmalya.aatithya.restmodule.account.model.AccountLedgerModel;

public class GenerateAccountLedgerParameter {

}
