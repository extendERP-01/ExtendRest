package nirmalya.aatithya.restmodule.common.utils;

public class GenerateAssignGymParameter {

}
